<body>
	<form method="post" action="envoyer_des_mails.php">
		<h2>Formulaire pour mot de passe oublié </h3>
		Saisir votre Adresse email : <input type="text" name="mail"><br><br>
		<input type="submit" name="Envoyer mon mot de passe" class="bouton"><br>
	</form>
<body>
<footer>
	<?php include("footer.php"); ?>
</footer>


<?php include("bandeau.php"); ?>

<body>
	<center><form method="post" action="traitementajoutexperience.php">
		<h2>Ajouter une expérience à votre profil </h3>
		Saisir votre Expérience : <input type="text" name="experience"><br><br>
		<input type="submit" name="Ajouter cette Expérience" class="bouton" value="Ajouter Expérience"><br>
	</form></center>
<body>
<footer>
	<?php include("footer.php"); ?>
</footer>

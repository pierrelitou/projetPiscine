<?php
mysqli_connect('localhost', 'root', '','piscine');
?>
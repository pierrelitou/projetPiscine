<?php include("bandeau.php"); ?>

<body>
	<center><form method="post" action="traitementajoutcentreinteret.php">
		<h2>Ajouter un centre d'intérêt à votre profil </h3>
		Saisir votre centre d'intérêt : <input type="text" name="centreinteret"><br><br>
		<input type="submit" name="Ajouter cet centreinteret" class="bouton" value="Ajouter Centre d'intérêt"><br>
	</form></center>
<body>
<footer>
	<?php include("footer.php"); ?>
</footer>

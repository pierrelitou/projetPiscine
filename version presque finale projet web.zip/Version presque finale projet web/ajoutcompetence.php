<?php include("bandeau.php"); ?>

<body>
	<center><form method="post" action="traitementajout.php">
		<h2>Ajouter une compétence à votre profil </h3>
		Saisir votre Compétence : <input type="text" name="competence"><br><br>
		<input type="submit" name="Ajouter cette compétence" class="bouton" value="Ajouter Compétence"><br>
	</form></center>
<body>
<footer>
	<?php include("footer.php"); ?>
</footer>

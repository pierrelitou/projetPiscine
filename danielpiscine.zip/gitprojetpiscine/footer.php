<!DOCTYPE html>

<head>
	<style type="text/css">
	#pied
	{
		background-color: RGB(53,143,127);
		height:30px; 
		width:100%;
		text-align: center;
		color: white;
	}
	</style>
</head>

<body>
	<p id="pied">Litou Pierre, Fornaciari Benjamin, Claro Carvalho Daniel - Projet Piscine 2018</p>
</body>
</html>